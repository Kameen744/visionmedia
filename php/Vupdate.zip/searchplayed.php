
<div class="col-md-2">
    <span class="label label-primary">Search By Name</span>
    <input type="text" id="searchPlayedNameText" class="form-control">
    <span class="label label-warning hidden">Press Enter Key To Search Record</span>
</div>

<div class="col-md-2">
    <span class="label label-warning">Search By Date</span>
    <input type="text" id="searchPlayedDateText" class="form-control pdate">
    <span class="label label-warning hidden">Press Enter Key To Search Record</span>
</div>

<div class="col-md-4" style="margin-left:20px;">   
    <div class="col-md-6" style="margin:0px; padding:0px;">          
        <span class="label label-success">Search From Date</span>           
        <input type="text" id="searchPlayedFromText" class="form-control pdate">
    </div>
    <div class="col-md-6" style="margin:0px; padding:0px;">          
        <span class="label label-success">Search To Date</span>
        <input type="text" id="searchPlayedToText" class="form-control pdate">
    </div>
</div>
<script>
    $(".pdate").datepicker({dateFormat: 'yy-mm-dd'});    
</script>
