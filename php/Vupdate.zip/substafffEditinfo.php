<?php
    if(isset($_POST['StaffIDNo'])) {
        $id = $_POST['StaffIDNo'];
    } else {
        $id = "";
    }
?>
<div class="panel panel-primary " style="padding:5px; background: rgba(20,20,20,0.8); margin-top: 5px;">
    <div class="panel-heading" style=" font-size: 20px;">
        <span class="label"><i class="fa fa-user fa-fw"></i>Edit Data</span> 
        <div class="pull-right">
            <button class="btn btn-danger btn-sm" id="editBioData" value="<?php echo $id?>">Edit Bio Data</button>
            <button class="btn btn-danger btn-sm" id="editSchools"value="<?php echo $id?>">Schools Attended</button> 
            <button class="btn btn-danger btn-sm" id="editSkillsExp"value="<?php echo $id?>">Skills & Experience</button>
            <button class="btn btn-danger btn-sm" id="editRefreesNex"value="<?php echo $id?>">Refrees</button>   
        </div>
    </div>
    <div class="panel-body">
        <div class="row" id="loadreports" style="color:white;">
        </div>
    </div>
</div>
       