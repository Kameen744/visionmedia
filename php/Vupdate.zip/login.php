<?php
	require "con_Vfm.php";
	
	if(isset($_POST['submit'])){
		$Unm = mysqli_real_escape_string($vfms_con, $_POST['username']);
		$Ps = mysqli_real_escape_string($vfms_con, $_POST['password']);
		$SLoc = mysqli_real_escape_string($vfms_con, $_POST['LogSelectLoc']);
	
		if($Unm !== "" & $Ps !== ""){

			if (!empty($SLoc)) {
				$stIDD = substr($SLoc, 0, 8);
				$chkqr = $vfms_con->query("SELECT ID, V_S_Location, V_User_Name, Station_ID FROM vsn_users WHERE Station_ID = '$stIDD' AND V_User_Name = '$Unm' AND V_User_Password = '$Ps' ");
				$res = $chkqr->fetch_array(MYSQLI_NUM);
				$id = $res[0];
				$location = $res[1];
				$user = $res[2];
				$silid = $res[3];
				if ($id > 0 & $location != "" & $user != "") {
					$stqr = $vfms_con->query("SELECT Station_ID, S_Location, S_Address FROM stations WHERE Station_ID = '$silid' ");
					$stres = $stqr->fetch_array(MYSQLI_NUM);
					if (!empty($stres[0])) {
						session_start();
						$_SESSION['vuserp'] = $user;
						$_SESSION['location'] = $location;
						$_SESSION['Station_ID_No'] = $stres[0];
						$_SESSION['Station_Location'] = $stres[1];
						$_SESSION['Station_Address'] = $stres[2];

						echo "<script>window.open('vuser_area.php', '_self')</script>";
					}
				} else {
						$subuserquer = $vfms_con->query("SELECT `ID`, `Sub_User_ID`, `V_S_username`,
						 `V_S_password`, `V_S_Location`, `Station_ID` FROM `vsn_sub_users` 
						 WHERE V_S_username = '$Unm' AND V_S_password = '$Ps' AND Station_ID = '$stIDD' ");

						$subuser = $subuserquer->fetch_array(MYSQLI_NUM);
					
						if ($subuser[0] > 0) {
							session_start();
							$_SESSION['Sub_UserID'] = $subuser[1];
							$_SESSION['vsubuserp'] = $subuser[2];
							$_SESSION['location'] = $subuser[4];
							$_SESSION['Station_ID_No'] = $subuser[5];
							echo "<script>window.open('vsub_user_area.php', '_self')</script>";
						} else {
							echo "<script>alert('Wrong! User Name or Password'); window.open('../index.php', '_self');</script>";
						}
				}
			} else {


			$sql = "SELECT * FROM login WHERE User_Name = '$Unm' AND Password = '$Ps' ";
			$stmt = $vfms_con->query($sql);
			$result = $stmt->fetch_array(MYSQLI_NUM);
				$ussn = $result[0];
				$psssn = $result[1];
				$pss = $result[2];

				if ($ussn[0] > 0) {
					session_start();
					$_SESSION['vadminp'] = $Unm;
					echo "<script>window.open('vadmin_area.php', '_self')</script>";
				}
				else{
					echo "<script>alert('Wrong! User Name or Password'); window.open('../index.php', '_self');</script>";
				}
			}

		}else{
			echo "Username and Password cannot be empty";
		}
	}
?>