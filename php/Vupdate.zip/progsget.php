<div class="col-md-8 col-md-offset-2" style="margin-bottom: 10px;">
    <button class="btn costbtn btn-danger pull-left" id="ProgramsSchedule" style="margin-top: 5px;">All Programs</button>
    <div class="col-md-3" style="padding: 0px;">
        <select id="progday" class="form-control costinpt">
        <option value="">Search Day</option>
        <option value="Monday">Monday</option>
        <option value="Tuesday">Tuesday</option>
        <option value="Wednesday">Wednesday</option>
        <option value="Thursday">Thursday</option>
        <option value="Friday">Friday</option>
        <option value="Saturday">Saturday</option>
        <option value="Sunday">Sunday</option>
    </select>
    </div>
    <div class="col-md-2" style="padding: 0px;">
        <input type="text" class="form-control col-md-4 costinpt" placeholder="Search Name" id="progname">
    </div>
    <button class="btn costbtn btn-danger pull-left" id="SearchProgs" style="margin-top: 5px;"><span class="glyphicon glyphicon-search"></span></button>
    <button class="btn costbtn btn-danger pull-left" id="getPresentations" style="margin-top: 5px; margin-left: 5px;">Presentation</button>    
</div>
<div class="col-md-12" id="ProgramsHhtmlres" style="padding: 0px;"></div>