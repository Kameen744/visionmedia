<?php
session_start();
if (isset($_SESSION['vsubuserp'])) {
    $stID = $_SESSION['Station_ID_No']; 
        
    if (isset($_POST['subUserID'])) {
        $StfID = $_POST['subUserID'];
        require "con_Vfm.php";

        $checkquer = $vfms_con->query("SELECT `Staff_ID`, 
        `C_Name` FROM `vsn_staff` WHERE Station_ID = '$stID' AND Staff_ID = '$StfID' ");
        $rows = $checkquer->fetch_array(MYSQLI_NUM);
        if (empty($rows[0])) {
            echo "True";
        } else {
            echo "C.V Created. Click View or Edit Information";
        }
    }
}
?>