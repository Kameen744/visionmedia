  <div class="panel panel-primary " style=" margin-top:5px; padding:5px; background: rgba(20,20,20,0.8);">
	    <div class="panel-heading" style=" font-size: 20px;">
	        <span class="label"><i class="fa fa-play fa-fw"></i>Playlist & Events History</span>

	        
	        <div class="pull-right">
  				<a href="#" style="text-decoration: none;" class="pnavbtn" id="VirtualPlaylistHistory">
				<span class="label label-danger pnavlabel">Virtual Dj</span>
				</a>

	        	<a href="#" style="text-decoration: none;" class="pnavbtn" id="PlaylistHistory">
				<span class="label label-danger pnavlabel">Radio Dj</span>
				</a>

				<a href="#" style="text-decoration: none;" class="pnavbtn" id="SoundTrackHist">
				<span class="label label-danger pnavlabel">Soundtrack</span>
				</a>

				<a href="#" style="text-decoration: none;" class="pnavbtn" id="RadioEvents">
				<span class="label label-danger pnavlabel">Events</span>
				</a>

				<a href="#" style="text-decoration: none;" class="pnavbtn" id="SearPlayedBy">
				<span class="label label-danger pnavlabel">Search By</span>
				</a>
<!--
				<a href="#" style="text-decoration: none;" class="pnavbtn" id="getid-3">
				<span class="label label-danger pnavlabel">Getid</span>
				</a>
			
	      		<a href="#" style="text-decoration: none;" class="pnavbtn" id="testm3u">
				<span class="label label-danger pnavlabel">M3 U Test</span>
				</a>
-->
	        </div>
	    </div>

	    <div class="panel-body">
	       <?php $ddte = date("d/m/Y");?>
			<input type="hidden" name="" value="<?php echo $ddte; ?>" id="todaysadd">
			<div class="row" id="loadreports" style="color:white;">

			</div>
	        <!-- /.row -->
	    </div>
	    <!-- /.panel-body -->
	</div>
	<script type="text/javascript">
		$(".logDatpick").datepicker({dateFormat: "yy-mm-dd"});
	</script>