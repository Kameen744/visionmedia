
<div style="padding-top:5px; text-align: center;">
	<h2 class="rgadfrm alert alert-danger">O A P</h2>	
<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">			
	<input type="text" name="oapfname" class="form-control costinpt" placeholder="First Name" required="" id="oapfname">
</div>
<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">
	<input type="text" name="oaplname" class="form-control costinpt" placeholder="Last Name" required="" id="oaplname">
</div>
<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">
	<input type="text" name="Phone Number" class="form-control costinpt" placeholder="Phone Number" required="" id="oapnumber" max="12">
</div>
<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">
	<input type="text" name="station" class="form-control costinpt" placeholder="Station" required="" id="oapstation">
</div>

<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">
	<input type="text" name="location" class="form-control costinpt" required="" placeholder="Location" id="oaplocation">
</div>
<div class="col-md-3" style="margin-top: 10px; margin-bottom: 10px;">
	<textarea type="text" name="programs" class="form-control costinpt" placeholder="Programs" required="" id="oapprograms"></textarea>
</div>


	<hr>
	<div class="col-md-12">
		<hr>
	<div class="col-xs-12" id="oapsuccess" style="display: none;">
		
	</div>
			<input type="submit" name="RegisterOap" value="Save Information" class="btn costbtn btn-danger btn-block" id="RegisterOap">
	</div>
	
</div>
