<?php
	session_start();
	if (isset($_SESSION['vadminp'])) {
		$stID = $_POST['scstID'];
	}

	if (isset($_SESSION['vuserp'])) {
		$stID = $_SESSION['Station_ID_No'];
	}
	require "con_Vfm.php";
	$record_per_page = 10;
	$output = "";
	$page = "";
	if (isset($_POST['page'])) {
		$page = $_POST['page'];
	}
	else{
		$page = 1;
	}

	$start_from_page = ($page - 1) * $record_per_page;

	$query = "SELECT ID, Client_Name, Client_Number, Advert_Name, Amount, Paid, Balance, Start_Date, End_Date, Slot, Num_Days, Remarks, Reg_By FROM register_advert WHERE Station_ID = '$stID' ORDER BY ID DESC LIMIT $start_from_page, $record_per_page";
	$result = $vfms_con->query($query);
	
	
	echo "<div class='col-md-4' style='margin-bottom:5px; padding:0px;'><button class='btn btn-danger btn-xs' id='PrintAllRecordsReport'><span class='glyphicon glyphicon-print'></span> Print</button></div>";
	$output .= "
		<table class='table table-bordered' style='margin-bottom: 5px;'>
		<tr>
			<th>S/N</th>
			<th>Client</th>
			<th>Number</th>
			<th>Advert</th>
			<th>Amount</th>
			<th>Paid</th>
			<th>Balance</th>
			<th>Start Date</th>
			<th>End Date</th>
			<th>Slots</th>
			<th>Days</th>
			<th>Reg By</th>
			<th>Remark</th>
		</tr>
	";
	while ($rows = $result->fetch_array(MYSQLI_NUM)){
		$sn = $rows[0];
		$Cname = $rows[1];
		$Cnum = $rows[2];
		$Aditem = $rows[3];
		$Amnt = $rows[4];
		$paid = $rows[5];
		$Balance = $rows[6];
		$startdate = $rows[7];
		$enddate = $rows[8];
		$slots = $rows[9];
		$days = $rows[10];
		$remark = $rows[11];
		$regby = $rows[12];
		
		$output .= "<tr>
				<td>$sn</td>
				<td>$Cname</td>
				<td>$Cnum</td>
				<td>$Aditem</td>
				<td>$Amnt</td>
				<td>$paid</td>
				<td>$Balance</td>
				<td>$startdate</td>
				<td>$enddate</td>
				<td>$slots</td>
				<td>$days</td>
				<td>$regby</td>
				<td>$remark</td>
				</tr>";
	}
	$output .= "
		</table>
	";
	$page_query = "SELECT * FROM register_advert WHERE Station_ID = '$stID' ORDER BY ID DESC";
	$page_result = $vfms_con->query($page_query);
	$total_records = mysqli_num_rows($page_result);
	$total_pages = ceil($total_records / $record_per_page);
	$output .= "<input type='hidden' value='$total_pages' id='TotalPages'>";

	for ($ii=1; $ii <= $total_pages; $ii++) { 
		$output .= "
			<span class='label label-primary page_link' style='cursor:pointer;' id='".$ii."'>".$ii."</span>
		";
	}

	echo $output;
?>