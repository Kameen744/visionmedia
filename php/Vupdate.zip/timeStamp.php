<?php 
date_default_timezone_set('Africa/Lagos');
echo "" .date('d/m/Y h:i:s A');
?>