  <div class="panel panel-primary " style=" margin-top:5px; padding:5px; background: rgba(20,20,20,0.8);">
	    <div class="panel-heading" style=" font-size: 20px;">
	        <span class="label"><i class="fa fa-exchange fa-fw"></i>Transactions</span>

	        
	        <div class="pull-right">
	        	<a href="#" style="text-decoration: none;" class="pnavbtn" id="GetAllTrans"> <span class="label label-warning pnavlabel">All Transactions </span>
				</a>

				<a href="#" style="text-decoration: none;" class="pnavbtn" id="TransByDate">
				<span class="label label-danger pnavlabel">Daily Transactions</span>
				</a>

				<a href="#" class="pnavbtn" id="TransSearchbydate">
				<span class="label label-danger pnavlabel">Search By</span>
				</a>
	        </div>
	    </div>

	    <div class="panel-body">
	       <?php $ddte = date("d/m/Y");?>
			<input type="hidden" name="" value="<?php echo $ddte; ?>" id="todaysadd">
			<div class="row" id="loadreports" style="color:white;">

			</div>
	        <!-- /.row -->
	    </div>
	    <!-- /.panel-body -->
	</div>