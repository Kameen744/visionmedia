<?php
	$vfms_con = new mysqli("localhost", "root", "", "radiodj2");
?>