<form id="presentationForm">
	<h2 class="rgadfrm alert alert-danger text-center">Presentation</h2>

<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">			
	<input type="text" name="programName" class="form-control costinpt" placeholder="Program" required="" id="program">
</div>
<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">			
	<input type="text" name="programTopicName" class="form-control costinpt" placeholder="Topic" required="" id="topicProgram">
</div>

<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">
	<select name="progType" class="form-control costinpt" required="">
		<option>Program Type</option>
		<option value="Live">Live</option>
		<option value="Recorded">Recorded</option>
	</select>
</div>

<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">
	<input class="form-control costinpt pdate" type="text" name="presDate" id="prone" placeholder="Date">
</div>

<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">
	<input class="form-control costinpt timeautocomp" type="text" name="presTime" id="prtwo" placeholder="Time">
</div>

<div class="col-md-2 col-md-offset-2" style="margin-top: 15px; margin-bottom: 10px;">
	<select name="noofguest" id="noofguestprest" class="form-control costinpt" required="">
		<option>No of guest</option>
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
	</select>
</div>
<div class="col-md-12">
<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_1">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_1" id="prthree" placeholder="Guest 1">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_1_num" id="prthree" placeholder="Guest Number">
	</div>
</div>

<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_2">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_2" id="prthree" placeholder="Guest 2">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_2_num" id="prthree" placeholder="Guest Number">
	</div>
</div>
<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_3">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_3" id="prthree" placeholder="Guest 3">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_3_num" id="prthree" placeholder="Guest Number">
	</div>
</div>
<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_4">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_4" id="prthree" placeholder="Guest 4">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_4_num" id="prthree" placeholder="Guest Number">
	</div>
</div>
<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_5">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_5" id="prthree" placeholder="Guest 5">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_5_num" id="prthree" placeholder="Guest Number">
	</div>
</div>
<div class="col-md-6" style="padding-right: 0px; display: none;" id="guest_6">
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_6" id="prthree" placeholder="Guest 6">
	</div>
	<div class="col-md-6" style="margin-top: 15px; margin-bottom: 10px;">
		<input class="form-control costinpt" type="text" name="gues_6_num" id="prthree" placeholder="Guest Number">
	</div>
</div>
</div>
</form>	
<div class="col-md-12 alert alert-success" id="presSuccessalert" style="display: none;">
	
</div>	
<div class="col-md-4 col-md-offset-4">
	<a href="#" id="savePresentDetails" class="btn btn-danger btn-block costbtn">Save</a>
</div>
<script>
$(".pdate").datepicker({dateFormat: 'yy-mm-dd'});
$(".timeautocomp").autocomplete({
		source: timeautocomp
	});
</script>
