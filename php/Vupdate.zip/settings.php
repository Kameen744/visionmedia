  <div class="panel panel-primary " style=" margin-top:5px; padding:5px; background: rgba(20,20,20,0.8);">
	    <div class="panel-heading" style=" font-size: 20px;">
	        <span class="label"><i class="fa fa-gear fa-fw"></i>Settings</span>
	          <div class="pull-right">
	        	<a href="#" class="btn btn-sm costbtn" id="RegStation"> <span>Register Stations</span>
				</a>

				<a href="#" class="btn btn-sm costbtn" id="RegUsers">
				<span>Add Users</span>
				</a>
	        </div>
	    </div>
	    <div class="panel-body">
	    <div class="col-md-12" style="padding: 0px; display: none;" id="Stationscontainer">
	    	<h2 class="rgadfrm alert alert-danger text-center">Register Stations</h2>
	    	<hr>	
	<div class="col-md-3" style="">
		<select class="form-control costinpt" id="Station" required="">
			<option value="">Station</option>
			<option value="Vision FM">Vision FM</option>
			<option value="Farin Wata">Farin Wata</option>
		</select>
	</div>
	<div class="col-md-3">
		<input type="text" class="form-control costinpt" id="Location" placeholder="State">
	</div>
	<div class="col-md-3">
		<input type="text" class="form-control costinpt" id="Address" placeholder="Address">
	</div>
	<div class="col-md-3">
		<input type="text" class="form-control costinpt" id="Cnumber" placeholder="Contact Number">
	</div>
	<div class="col-md-12">
		<hr>
		<button class="btn btn-block costbtn" id="SaveStation">Save Station</button>
	</div>
	</div>

	<div class="col-md-12" style="padding: 0px; display: none;" id="Userscontainer">
		<h2 class="rgadfrm alert alert-danger text-center">Add Users</h2>
		<hr>

		<div class="col-md-3">
			<input type="text" class="form-control costinpt" id="VUserName" placeholder="UserName">
		</div>
		<div class="col-md-3">
			<input type="text" class="form-control costinpt" id="VPassword" placeholder="Password">
		</div>
		<div class="col-md-3" style="">
			<select class="form-control costinpt" id="StLocation" required="">
				<option value="">Station/Location</option>
			</select>
		</div>
		<div class="col-md-3">
			<input type="text" class="form-control costinpt" id="VStatus" placeholder="Status">
		</div>
		
		<div class="col-md-12">
			<hr>
			<button class="btn btn-block costbtn" id="SaveUser">Save User</button>
		</div>
	</div>

	<div class="col-md-12 text-center" style="display:none;" id="settingsalert">
	<hr>
	</div>
	</div>
	</div>
<script>
	$("#Location").autocomplete({
		source: ['Abuja', 'Adamawa', 'Bauchi', 'Maiduguri', 'Niger', 'Kano', 
		'Kaduna', 'Katsina', 'Kebbi', 'Sokoto', 'Gombe', 'Zamfara'
		]
	});	
</script>