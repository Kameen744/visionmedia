<div class="col-md-12" style="margin-bottom: 10px;">
    <div class="col-md-3" style="padding: 0px;">
        <input type="text" id="veryprogday" class="form-control costinpt pdate">
    </div>
    <button class="btn costbtn btn-danger pull-left" id="verySearchProgs" style="margin-top: 5px;">
        <span class="glyphicon glyphicon-search"></span>
    </button>
</div>
<div class="col-md-12" id="VerifyHhtmlres" style="padding: 0px;"></div>

<script>
    $(".pdate").datepicker({dateFormat: 'yy-mm-dd'});
</script>