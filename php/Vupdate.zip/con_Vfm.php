<?php
	$vfms_con = new mysqli("localhost", "root", "", "visiondb");
	$vfms_virtual = new mysqli("localhost", "root", "", "virtualdjlog");
	// $vfmsradio_con = new mysqli("localhost", "root", "", "radiodj2");
?>