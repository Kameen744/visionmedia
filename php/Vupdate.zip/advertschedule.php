<div class="input-group col-xs-4 col-xs-offset-4">
    <input type="text" name="srchdate" id="srchdate" class="form-control" placeholder="Search Adverts Schedule by Date" style="background: rgba(250,250,250,0.3); color: 
        white;">
    <div class="input-group-btn">
            <button class="btn btn-success" style="margin-top: 5px;" id="SerchByDate">Search</button>
        </div>
    </div>
<script type="text/javascript">
    $("#srchdate").datepicker({dateFormat: "yy-mm-dd"});
</script>