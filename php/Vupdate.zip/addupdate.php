  <div class="panel panel-primary " style="padding:5px; background: rgba(20,20,20,0.8); margin-top: 5px;">
	    <div class="panel-heading" style=" font-size: 20px;">
	        <span class="label"><i class="fa fa-print fa-fw"></i>Print Reports</span>

	        <div class="pull-right">
	        	<a href="#" style="text-decoration: none;" class="pnavbtn" onclick="printalladrec();" id="printAllAdverts"> <span class="label label-danger pnavlabel"> Print All Records </span>
				</a>

				<a href="#" style="text-decoration: none;" class="pnavbtn" onclick="advertSchedule();" id="AdvertSchedule">
				<span class="label label-danger pnavlabel">Adverts Schedule</span>
				</a>

				<a href="#" onclick="getHistory();" class="pnavbtn" id="getHistory">
				<span class="label label-danger pnavlabel">Monthly Report</span>
				</a>

	        </div>
	    </div>

	    <div class="panel-body">
	       <?php $ddte = date("d/m/Y");?>
			<input type="hidden" name="" value="<?php echo $ddte; ?>" id="todaysadd">
			<div class="row" id="loadreports" style="color:white;">

			</div>
	        <!-- /.row -->
	    </div>
	    <!-- /.panel-body -->
	</div>