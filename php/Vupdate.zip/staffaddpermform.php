<form class="col-md-12" style="padding-bottom: 5px;" id="RegStaffForm">
	<h2 class="rgadfrm alert alert-danger">New User</h2>	

 <div class="col-md-3 regformcontrol">			
	<input type="text" id="User_Name" class="form-control costinpt" placeholder="User Name" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" id="User_Password" class="form-control costinpt" placeholder="Password">
</div>

<div class="col-md-12 regformcontrol">
<hr>
    <a class="costbtn btn btn-danger" id="SaveUserPerm">Save</a>
</div>
<div class="col-md-12" id="saveSucResponse">
    
</div>
</form>