<form class="col-md-12" style="padding-bottom: 5px;" id="RegStaffForm">
	<h2 class="rgadfrm alert alert-danger">Bio Data</h2>	

<div class="col-md-3 regformcontrol">			
	<input type="text" name="S_Name" class="form-control costinpt" placeholder="Full Name" required="" id="ClientNameInput">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Number" class="form-control costinpt" maxlength="11" placeholder="Phone Number" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="email" name="S_Email" class="form-control costinpt" placeholder="E-Mail" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="date" name="S_Dateofbirth" class="form-control costinpt" placeholder="Date of Birth" required="">
</div>
<div class="col-md-3 regformcontrol">
	<select type="text" name="S_Gender" class="form-control costinpt" required="">
		<option value="">Gender</option>
		<option value="Male">Male</option>
		<option value="Female">Female</option>
	</select>
</div>
<div class="col-md-3 regformcontrol">
	<select type="text" name="S_Maritalstatus" class="form-control costinpt" required="">
		<option value="">Marital Status</option>
		<option value="Maried">Maried</option>
		<option value="Single">Single</option>
	</select>
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Natiolity" class="form-control costinpt" required="" placeholder="Nationaliy" >
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_State" class="form-control costinpt" required="" placeholder="State of Origin" >
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Lga" class="form-control costinpt" placeholder="L.G.A" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Address" class="form-control costinpt" placeholder="Contact Address">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Qualification" class="form-control costinpt" placeholder="Qualification">
</div>	
<div class="col-md-3 regformcontrol">
	<select type="text" name="S_Title" id="S_Title" class="form-control costinpt" required="">
		<option value="">Job Title</option>
		<option value="Account/Admin Manager">Account/Admin Manager</option>
		<option value="Camera Man">Camera Man</option>
		<option value="Cleaner">Cleaner</option>
		<option value="Driver">Driver</option>
		<option value="DCA">DCA</option>
		<option value="Editor">Editor</option>
		<option value="Engineer">Engineer</option>
		<option value="General Manager">General Manager</option>
		<option value="Head of Production">Head of Production</option>
		<option value="Head of Programe">Head of Programe</option>
		<option value="IT Officer">IT Officer</option>
		<option value="Producer">Producer</option>
		<option value="Manager Programs">Manager Programs</option>
		<option value="Presenter">Presenter</option>
		<option value="Senior Producer">Senior Producer</option>
		<option value="Reporter">Security</option>
		<option value="Studio Manager">Studio Manager</option>
		<option value="Sound Man">Sound Man</option>
		<option value="Reporter">Reporter</option>
		<option value="Reporter">Receptionist</option>
	</select>
</div>
<div class="col-md-3 regformcontrol">
	<select type="text" name="S_Level" id="S_Level" class="form-control costinpt" disabled="">
		<option value="">Grade Level</option>
		<option value="Level 01">Level 01</option>
		<option value="Level 02">Level 02</option>
		<option value="Level 03">Level 03</option>
		<option value="Level 04">Level 04</option>
		<option value="Level 05">Level 05</option>
		<option value="Level 06">Level 06</option>
		<option value="Level 07">Level 07</option>
		<option value="Level 08">Level 08</option>
		<option value="Level 09">Level 09</option>
		<option value="Level 10">Level 10</option>
		<option value="Level 11">Level 11</option>
		<option value="Level 12">Level 12</option>
		<option value="Level 13">Level 13</option>
		<option value="Level 14">Level 14</option>
		<option value="Level 15">Level 15</option>
		<option value="Level 16">Level 16</option>
	</select>
</div>
<div class="col-md-3 regformcontrol">
	<select type="text" name="S_Bank" id="S_Bank" class="form-control costinpt" required="">
		<option value="">Bank</option>
		<option value="Access Bank">Access Bank</option>
		<option value="Diamond Bank">Diamond Bank</option>
		<option value="First Bank">First Bank</option>
		<option value="Guaranty Trust Bank">Guaranty Trust Bank</option>
		<option value="JAIZ Bank">JAIZ Bank</option>
		<option value="Keystone Bank">Keystone Bank</option>
		<option value="Union Bank">Union Bank</option>
		<option value="United Bank for Africa">United Bank for Africa</option>
		<option value="Unity Bank">Unity Bank</option>
		<option value="Zenith Bank">Zenith Bank</option>
		<option value=""></option>
	</select>
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_AccName" class="form-control costinpt" placeholder="Account Name">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_AccNumber" class="form-control costinpt" placeholder="Account Number">
</div>
<hr>
<div class="col-md-12 alert alert-success text-center" id="savestaffidsuccess" style="display: none;">	
</div>
<div class="col-md-12">
	<hr>
	<a id="RegisterNewStaff" class="btn costbtn btn-danger btn-block bnt-xx">Save & Next</a>
</div>
	<hr>
</form>

<!-- Schools Attended with dates -->
<form class="col-md-12" style="padding-bottom: 5px; display: none;" id="SchoolsAttendedDates">
	<h2 class="rgadfrm alert alert-danger">Schools Atended with Dates</h2>	
<div id="SchoolsFormArea">
	<div style="display: none;" class="sfIDNo">
		
	</div>
	<!-- Primary School -->
	<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Primary School</label>
		<input name="S_Primary" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Qualification Obtained</label>
		<input name="S_PrimaryQual" class="form-control costinpt" placeholder="Primary School Certificate" id="PrmQl">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Start From</label>
		<input type="date" name="S_Prfrom" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Finished</label>
		<input type="date" name="S_Prto" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	</div>

		<!-- Secondary School -->
	<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Secondary School</label>
		<input name="S_Secondary" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Qualification Obtained</label>
		<input name="S_SecondaryQual" class="form-control costinpt" placeholder="Senior Secondary School Cerficate" id="SecQl">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Start From</label>
		<input type="date" name="S_Secfrom" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Finished</label>
		<input type="date" name="S_Secto" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	</div>

		<!-- Tertiary  -->
	<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Tertiary Institution</label>
		<input name="S_Tertiary" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding:0px;">
		<label class="label label-danger">Qualification Obtained</label>
		<input name="S_TertiaryQual" class="form-control costinpt" placeholder="ND, OND, HND, NCE, BSc">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Start From</label>
		<input type="date" name="S_Terfrom" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Finished</label>
		<input type="date" name="S_Terto" class="form-control costinpt" placeholder="1999-12-15">
	</div>
	</div>

</div>
<div class="col-md-12" style="padding-top: 10px;">
	<a class="btn btn-danger btn-xs costbtn col-md-4 col-md-offset-4" id="AddMoreSchools"><span class="glyphicon glyphicon-plus"> Add More Schools</span></a>
</div>
<hr>
<div class="col-md-12 alert alert-success text-center" id="SchoolsAttendedsuccess" style="display: none;">	
</div>
<div class="col-md-12">
	<hr>
	<a id="SchoolsAttended" class="btn costbtn btn-danger btn-block bnt-xx">Save & Next</a>
</div>
<hr>
</form>
<!-- Skills & Experience -->
<form form class="col-md-12" style="padding-bottom: 5px; display: none;" id="SkillsExperience">
	<h2 class="rgadfrm alert alert-danger">Skills & Experience</h2>	
<div style="display: none;" class="sfIDNo">
		
</div>
<div class="col-md-12" id="SkillsContain">
	<div class="col-md-3 regformcontrol">			
		<input type="text" name="skill_1" class="form-control costinpt" placeholder="Skill 1">
	</div>
	<div class="col-md-3 regformcontrol">			
		<textarea type="text" name="skillDes_1" class="form-control costinpt" placeholder="Description 1"></textarea>
	</div>
	<div class="col-md-3 regformcontrol">			
		<input type="text" name="skill_2" class="form-control costinpt" placeholder="Skill 2">
	</div>
	<div class="col-md-3 regformcontrol">			
		<textarea type="text" name="skillDes_2" class="form-control costinpt" placeholder="Description 2"></textarea>
	</div>
	
</div>
<div class="col-md-12" style="padding-top: 10px;">
	<a class="btn btn-danger btn-xs costbtn col-md-4 col-md-offset-4" id="AddMoreSkills"><span class="glyphicon glyphicon-plus">More Skills</span></a>
</div>

<div class="col-md-12"> 
	<hr>
</div>

<div class="col-md-12" id="ExperienceContain">
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Job Title</i>			
		<input type="text" name="job_1" class="form-control costinpt" placeholder="Job Title">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Company</i>				
		<input type="text" name="jobcom_1" class="form-control costinpt" placeholder="Company">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Start Date</i>				
		<input type="date" name="jobdatefrom_1" class="form-control costinpt" placeholder="From">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">End Date. Skip if still working there</i>				
		<input type="date" name="jobdateto_1" class="form-control costinpt" placeholder="To">
	</div>
	
</div>
	<div class="col-md-12" style="padding-top: 10px;">
		<a class="btn btn-danger btn-xs costbtn col-md-4 col-md-offset-4" id="AddMoreExperience"><span class="glyphicon glyphicon-plus">More Experience</span></a>
	</div>
<div class="col-md-12">
	<hr>
	<a id="SkillsExperienceSubmit" class="btn costbtn btn-danger btn-block bnt-xx">Save & Next</a>
</div>
</form>

	<!-- Next of Kin & Refrees -->
<form class="col-md-12" style="padding-bottom: 5px; display: none;" id="NexofkinandRefrees">
	<h2 class="rgadfrm alert alert-danger">Next of Kin & Refrees</h2>	
	<!-- Next of Kin  -->
<div style="display: none;" class="sfIDNo">
		
</div>
<div class="col-md-3 regformcontrol">			
	<input type="text" name="S_Nexofkin" class="form-control costinpt" placeholder="Next of kin" required="" >
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Nexofkinrel" class="form-control costinpt" placeholder="Relationship" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Nexofkinnum" class="form-control costinpt" placeholder="Number" required="">
</div>
<div class="col-md-3 regformcontrol">
	<input type="text" name="S_Nexofkinadd" class="form-control costinpt" placeholder="Address" required="">
</div>
	<!-- Refree 1  -->
<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4">
		<label class="label label-danger">Referee 1</label>
		<input name="S_Refreeone" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding: 0px;">
		<label class="label label-danger">Title</label>
		<input type="text" name="S_Refonetit" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Phone Number</label>
		<input type="text" name="S_Refonenum" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Address</label>
		<textarea type="text" name="S_Refoneadd" class="form-control costinpt" placeholder=""></textarea>
	</div>
</div>
	<!-- Refree 2  -->
<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4">
		<label class="label label-danger">Referee 2</label>
		<input name="S_Refreetwo" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding: 0px;">
		<label class="label label-danger">Title</label>
		<input type="text" name="S_Reftwotit" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Phone Number</label>
		<input type="text" name="S_Reftwonum" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Address</label>
		<textarea type="text" name="S_Reftwoadd" class="form-control costinpt" placeholder=""></textarea>
	</div>
</div>

<!-- Refree 3  -->
<div class="col-md-12" style="padding:0px; padding-top: 10px;">
	<div class="col-md-4">
		<label class="label label-danger">Referee 2</label>
		<input name="S_Refreethree" class="form-control costinpt">
	</div>
	<div class="col-md-4" style="padding: 0px;">
		<label class="label label-danger">Title</label>
		<input type="text" name="S_Refthreetit" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Phone Number</label>
		<input type="text" name="S_Refthreenum" class="form-control costinpt" placeholder="">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">Address</label>
		<textarea type="text" name="S_Refthreeadd" class="form-control costinpt" placeholder=""></textarea>
	</div>
</div>


<hr>
<div class="col-md-12 alert alert-success text-center" id="NexofkinRefsuccess" style="display: none;">	
</div>
<div class="col-md-12">
	<hr>
	<a id="NexofkinRef" class="btn costbtn btn-danger btn-block bnt-xx">Save & Finish</a>
</div>
	<hr>
</form>

<script>
	$("#SecQl").autocomplete({
		source: ['Senior Secondary School Cerficate']
	});
	$("#PrmQl").autocomplete({
		source: ['Primary School Certificate']
	});
	$(".timeautocomp").autocomplete({
		source: timeautocomp
	});
	$(".pdate").datepicker({dateFormat: 'yy-mm-dd'});
</script>
