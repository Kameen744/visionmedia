<form id="RegProgramsForm">
	<h2 class="rgadfrm alert alert-danger text-center">Programs</h2>
<div class="col-md-12">
	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">			
		<input type="text" name="prog" class="form-control costinpt" placeholder="Program" required="" id="program">
	</div>

	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">
		<input type="text" class="form-control costinpt" name="produc" id="producer" placeholder="Producer" required="">
	</div>
	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px;">
		<select name="nopr" id="noofpresenters" class="form-control costinpt" required="">
			<option>No of Presenters</option>
			<option value="1">One</option>
			<option value="2">Two</option>
			<option value="3">Three</option>
		</select>
	</div>

	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px; display: none;" id="pr1">
		<input class="form-control costinpt" type="text" name="pr1" id="prone" placeholder="Presenter ">
	</div>
</div>

<div class="col-md-12">
	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px; display: none;" id="pr2">
		<input class="form-control costinpt" type="text" name="pr2" id="prtwo" placeholder="Second Presenter">
	</div>
	<div class="col-md-3" style="margin-top: 15px; margin-bottom: 10px; display: none;" id="pr3">
		<input class="form-control costinpt" type="text" name="pr3" id="prthree" placeholder="Third Presenter">
	</div>
</div>

<div class="col-md-12">
	<hr>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">From: Eg. 01:00 PM</label>
		<input type="text" class="form-control costinpt timeautocomp" name="frm" placeholder="01:00 PM" id="sunfr" maxlength="8" minlength="8">
	</div>
	<div class="col-md-2" style="padding: 0px;">
		<label class="label label-danger">To: Eg. 01:30 PM</label>
		<input type="text" class="form-control costinpt timeautocomp" name="tto" placeholder="01:30 PM" id="sunto" maxlength="8" minlength="8">
	</div>

	<div class="col-md-8" style="padding: 0px;">
		<div class="col-md-12">
			<label class="label label-danger">Fresh/Repeat</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Daily" id="DailyLab">Daily
			<input type="checkbox" name="Daily" value="" id="Daily">
			</label>
			
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Mon" id="MonLab">Monday
				<input type="checkbox" name="Mon" value="" id="Mon">
			</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Tue" id="TueLab">Tuesday
				<input type="checkbox" name="Tue" value="" id="Tue">
			</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Wed" id="WedLab">Wednesday
				<input type="checkbox" name="Wed" value="" id="Wed">
			</label>	
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Thu" id="ThuLab">Thursday
				<input type="checkbox" name="Thu" value="" id="Thu">
			</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Fri" id="FriLab">Friday
				<input type="checkbox" name="Fri" value="" id="Fri">
			</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Sat" id="SatLab">Saturday
				<input type="checkbox" name="Sat" value="" id="Sat">
			</label>
		</div>
		<div class="col-md-3 labelcol">
			<label class="label label-primary pointlabel" for="Sun" id="SunLab">Sunday
				<input type="checkbox" name="Sun" value="" id="Sun">
			</label>
		</div>
	</div>
	
	<div class="col-md-12">
		<a class="btn costbtn btn-danger pull-left" id="SunSets">Save</a>
	</div>
		
</form>		
<div class="col-md-12" id="regProgResp">

</div>


<script>
$(".timeautocomp").autocomplete({
	source: timeautocomp
});
$( "#noofpresenters" ).change(function(){
	var prval = $(this).val();
	if (prval == 1) {
		$("#pr1, #pr2, #pr3").fadeOut();
		$("#pr1").fadeIn();
	}
	else if (prval == 2) {
		$("#pr1, #pr2, #pr3").fadeOut();
		$( "#pr1, #pr2").fadeIn();
	}
	else if (prval == 3) {
		$("#pr1, #pr2, #pr3").fadeOut();
		$( "#pr1, #pr2, #pr3").fadeIn();
	}
})
</script>
