  <div class="panel panel-primary col-md-12" style=" margin-top:5px; padding:5px; background: rgba(20,20,20,0.8);">
	    <div class="panel-heading" style=" font-size: 20px;">
	        <span class="label"><i class="fa fa-print fa-fw"></i>Print Reports</span>
	        <div class="pull-right" style="margin-right: 20px;">
	        	<a href="#" style="text-decoration: none;" class="pnavbtn" onclick="printalladrec();" id="printAllAdverts"> <span class="label label-danger pnavlabel"> Print All Records </span>
				</a>
				<a href="#" style="text-decoration: none;" class="pnavbtn" id="AdvertSchedule">
				<span class="label label-danger pnavlabel">Adverts Schedule</span>
				</a>

				<a href="#" id="getHistory" class="pnavbtn" id="getHistory">
				<span class="label label-danger pnavlabel">Monthly Report</span>
				</a>
				<a href="#" style="text-decoration: none;" class="dropdown-toggle pnavbtn" data-toggle="dropdown">
				<span class="label label-danger pnavlabel" id="progsget">Programs</span>
				</a>
				<a href="#" style="text-decoration: none;" class="dropdown-toggle pnavbtn" data-toggle="dropdown">
				<span class="label label-danger pnavlabel" id="progsVerify">Verify Log</span>
				</a>
				<a href="#" style="text-decoration: none;" class="dropdown-toggle pnavbtn" data-toggle="dropdown">
				<span class="label label-danger pnavlabel" id="oapgetrs">O A P</span>
				</a>
	        </div>
	    </div>

	    <div class="panel-body col-md-12 col-sm-12 col-xs-12">
	       <?php date_default_timezone_set('Africa/Lagos'); $ddte = date("d/m/Y");?>
			<input type="hidden" name="" value="<?php echo $ddte; ?>" id="todaysadd">
			<div class="row" id="loadreports" style="color:white;">
			</div>
	        <!-- /.row -->
	    </div>
	    <!-- /.panel-body -->
	</div>


