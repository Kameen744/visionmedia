<?php
session_start();
require "con_Vfm.php";
if (isset($_SESSION['vsubuserp'])) {
    $stID = $_SESSION['Station_ID_No']; 
    $subuserid = $_SESSION['Sub_UserID'];
    $ssnm = $_SESSION['vsubuserp'];
    $location = $_SESSION['location'];
}
if(isset($_POST['StaffIDNo'])){
    if(!empty($_POST['StaffIDNo'])) {
      $subuserid = $_POST['StaffIDNo'];
      $stID = $_SESSION['Station_ID_No']; 
    }
}
$expquer = $vfms_con->query("SELECT `Staff_ID`, `Skill_1`, `SkillDesc_1`, 
`Skill_2`, `SkillDesc_2`, `Skill_3`, `SkillDesc_3`, `Skill_4`, `SkillDesc_4`, `Skill_5`, 
`SkillDesc_5`, `Job_1`, `JobCom_1`, `JobFrom_1`, `JobTo_1`, `Job_2`, `JobCom_2`, `JobFrom_2`, 
`JobTo_2`, `Job_3`, `JobCom_3`, `JobFrom_3`, `JobTo_3`, `Job_4`, `JobCom_4`, `JobFrom_4`, `JobTo_4`, 
`Job_5`, `JobCom_5`, `JobFrom_5`, `JobTo_5` 
FROM `vsn_staff_expr` WHERE `Staff_ID` = '$subuserid' AND `Station_ID` = '$stID'");
$row = $expquer->fetch_array(MYSQLI_NUM);
$out = '
<form form class="col-md-12" style="padding-bottom: 5px;" id="SkillsExperienceEdit">
    <h2 class="btn btn-danger btn-block btn-xs costbtn">Skills</h2>	
    <input type="hidden" name="staffID_No" value="'.$subuserid.'">
<div style="display: none;" class="sfIDNo">
		
</div>
<div class="col-md-12" id="SkillsContain">
    <div class="col-md-3 regformcontrol">
        <i class="label label-danger">Skill</i>			
		<input type="text" name="skill_1" class="form-control costinpt" value="'.$row[1].'">
	</div>
    <div class="col-md-3 regformcontrol">
        <i class="label label-danger">Description</i>				
		<input type="text" name="skillDes_1" class="form-control costinpt" value="'.$row[2].'">
	</div>
    <div class="col-md-3 regformcontrol">
    	<i class="label label-danger">Skill</i>
		<input type="text" name="skill_2" class="form-control costinpt" value="'.$row[3].'">
	</div>
    <div class="col-md-3 regformcontrol">
        <i class="label label-danger">Description</i>			
		<input type="text" name="skillDes_2" class="form-control costinpt" value="'.$row[4].'">
	</div>';

if(!empty($row[5])) {
    $out .= '
        <div class="col-md-3 regformcontrol">			
		<input type="text" name="skill_1" class="form-control costinpt" value="'.$row[5].'">
		</div>
		<div class="col-md-3 regformcontrol">			
		<input type="text" name="skillDes_1" class="form-control costinpt" value="'.$row[6].'">
		</div>
    ';
}
if(!empty($row[7])) {
    $out .= '
        <div class="col-md-3 regformcontrol">			
		<input type="text" name="skill_2" class="form-control costinpt" value="'.$row[7].'">
		</div>
		<div class="col-md-3 regformcontrol">			
		<input type="text" name="skillDes_2" class="form-control costinpt" value="'.$row[8].'">
		</div>
    ';
}
if(!empty($row[9])) {
    $out .= '
        <div class="col-md-3 regformcontrol">			
		<input type="text" name="skill_3" class="form-control costinpt" value="'.$row[9].'">
		</div>
		<div class="col-md-3 regformcontrol">			
		<input type="text" name="skillDes_3" class="form-control costinpt" value="'.$row[10].'">
		</div>
    ';
}

$out .= '</div>
<div class="col-md-12" style="padding-top: 10px;">
	<a class="btn btn-danger btn-xs costbtn col-md-4 col-md-offset-4" id="AddMoreSkills"><span class="glyphicon glyphicon-plus"> More Skills</span></a>
</div>
<div class="col-md-12"> 
	<h2 class="btn btn-danger btn-block btn-xs costbtn">Workig Experience</h2>	
</div>

<div class="col-md-12" id="ExperienceContain">
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Job Title</i>			
		<input type="text" name="job_1" class="form-control costinpt" value="'.$row[11].'">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Company</i>				
		<input type="text" name="jobcom_1" class="form-control costinpt" value="'.$row[12].'">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">Start Date</i>				
		<input type="date" name="jobdatefrom_1" class="form-control costinpt" value="'.$row[13].'">
	</div>
	<div class="col-md-3 regformcontrol">
		<i class="label label-danger">End Date</i>				
		<input type="date" name="jobdateto_1" class="form-control costinpt" value="'.$row[14].'">
	</div>';
	if (!empty($row[15])) {
        $out .= '
        <div class="col-md-3 regformcontrol">
			<i class="label label-danger">Job Tittle</i>			
			<input type="text" name="job_1" class="form-control costinpt" value="'.$row[15].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Company</i>				
			<input type="text" name="jobcom_1" class="form-control costinpt" value="'.$row[16].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Start Date</i>				
			<input type="date" name="jobdatefrom_1" class="form-control costinpt" value="'.$row[17].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">End Date</i>				
			<input type="date" name="jobdateto_1" class="form-control costinpt" value="'.$row[18].'">
		</div>
        ';
    }
    if (!empty($row[19])) {
        $out .= '
        <div class="col-md-3 regformcontrol">
			<i class="label label-danger">Job Tittle</i>			
			<input type="text" name="job_2" class="form-control costinpt" value="'.$row[19].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Company</i>				
			<input type="text" name="jobcom_2" class="form-control costinpt" value="'.$row[20].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Start Date</i>				
			<input type="date" name="jobdatefrom_2" class="form-control costinpt" value="'.$row[21].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">End Date</i>				
			<input type="date" name="jobdateto_2" class="form-control costinpt" value="'.$row[22].'">
		</div>
        ';
    }
    	if (!empty($row[23])) {
        $out .= '
        <div class="col-md-3 regformcontrol">
			<i class="label label-danger">Job Tittle</i>			
			<input type="text" name="job_3" class="form-control costinpt" value="'.$row[23].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Company</i>				
			<input type="text" name="jobcom_3" class="form-control costinpt" value="'.$row[24].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Start Date</i>				
			<input type="date" name="jobdatefrom_3" class="form-control costinpt" value="'.$row[25].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">End Date</i>				
			<input type="date" name="jobdateto_3" class="form-control costinpt" value="'.$row[26].'">
		</div>
        ';
    }
    if (!empty($row[27])) {
        $out .= '
        <div class="col-md-3 regformcontrol">
			<i class="label label-danger">Job Tittle</i>			
			<input type="text" name="job_4" class="form-control costinpt" value="'.$row[27].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Company</i>				
			<input type="text" name="jobcom_4" class="form-control costinpt" value="'.$row[28].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">Start Date</i>				
			<input type="date" name="jobdatefrom_4" class="form-control costinpt" value="'.$row[29].'">
		</div>
		<div class="col-md-3 regformcontrol">
			<i class="label label-danger">End Date</i>				
			<input type="date" name="jobdateto_4" class="form-control costinpt" value="'.$row[30].'">
		</div>
        ';
    }
$out .= '</div>
	<div class="col-md-12" style="padding-top: 10px;">
		<a class="btn btn-danger btn-xs costbtn col-md-4 col-md-offset-4" id="AddMoreExperience"><span class="glyphicon glyphicon-plus"> More Experience</span></a>
    </div>
<div class="col-md-12 text-center" id="skillsEditSuccess">	
</div>
<div class="col-md-12">
	<hr>
	<a id="SkillsExperienceUpdate" class="btn costbtn btn-danger btn-block bnt-xx">Update</a>
</div>
</form>
';
echo $out;